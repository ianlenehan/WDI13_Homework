funText
=======

A [plugin for jQuery](http://plugins.jquery.com/funtext/)/Zepto that adds colorful 3D shadows to text which respond to mouse movement.

Find out more about how it looks and how it works on the [demo page](http://briznad.github.io/funText/).
